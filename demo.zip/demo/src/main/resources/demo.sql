drop table if exists demo
create table demo(
id int primary key,
name varchar(255) NOT NULL
);