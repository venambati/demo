package com.odx.test.restservices.services;

public class PalindromeNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PalindromeNotFoundException(String message) {
		super(message);
	}

}
